// ==UserScript==
// @name         美化 - 百度图标
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.baidu.com/*
// @grant        none
// @require      https://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==


(function(){
    $("#result_logo").remove();
    $('#lg').after("<img src='https://cdn.jsdelivr.net/gh/you-bowen/func_picgo/20200829115033.gif' height=66/>")
    //https://cdn.jsdelivr.net/gh/you-bowen/func_picgo/20200824130238.gif
})();