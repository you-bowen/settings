// ==UserScript==
// @name         colab 云盘简易登录
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://accounts.google.com/signin/oauth/*
// @match        https://accounts.google.com/o/oauth2/*
// @match        https://accounts.google.com/o/oauth2/auth/*
// @grant        none
// @require      https://code.jquery.jcom/jquery-1.12.4.min.js
// ==/UserScript==
window.onload = function(){
  console.log('fefjiasd');
  const ybw = document.getElementsByClassName("qQWzTd")[0];
  if (ybw) {
    ybw.click();
  }
  const allow = document.getElementsByClassName("VfPpkd-dgl2Hf-ppHlrf-sM5MNb");
  if (allow.length) {
    allow[0].click();
  }
  const copy = document.getElementsByClassName(
    "U26fgb mUbCce fKz7Od YYBxpf NCTw7e"
  );
  if (copy) {
    copy[0].click();
  }
}


