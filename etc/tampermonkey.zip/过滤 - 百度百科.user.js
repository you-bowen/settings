// ==UserScript==
// @name         过滤 - 百度百科
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://baike.baidu.com/item/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('body > div.lemmaWgt-searchHeader').remove()
    $('body > div.header-wrapper.pc-header-new').remove()
    $('body > div.navbar-wrapper').remove()
    $('body > div.body-wrapper > div.before-content').remove()
    $('#side-share').remove()
    $('body > div.body-wrapper > div.content-wrapper > div > div.side-content > div.lemmaWgt-promotion-vbaike').remove()
    $('body > div.body-wrapper > div.content-wrapper > div > div.side-content > div.lemmaWgt-promotion-slide').remove()
    // Your code here...
})();