// ==UserScript==
// @name         cqupt抢课绕过验证码
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://xk1.cqupt.edu.cn
// @grant        none
// @require      https://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    var flag = 0;
    function sleep(n) { //n表示的毫秒数
        var start = new Date().getTime();
        while (true) if (new Date().getTime() - start > n) break;
    }
    function down(selector, name) {
        console.log('download started');
        var a = document.createElement('a')
        a.download = name || 'pic'
        a.href = 'http://xk1.cqupt.edu.cn/createValidationCode.php'
        a.click();
    }
    $('#loginForm > input:nth-child(2)')[0].value = '2019210363'
    $('#loginForm > input:nth-child(5)')[0].value = '061710'
    down()
    $.post('http://192.168.13.1:8921',0,function(data){
        console.log('ok');
        $('#vCode')[0].value = data;
        $.post("checkLogin.php", $("#loginForm").serialize(),function(d){
            if (d.code!=0) {
                console.log('no');
                flag = 0;
            }
            else  {
                location.href='yxk.php';
                flag = 1;
            }
        },"json");
    })
})();