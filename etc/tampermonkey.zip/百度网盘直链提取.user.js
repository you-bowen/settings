// ==UserScript==
// @namespace zyxubing
// @name 百度网盘直链提取
// @description This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @version 0.0.22.1
// @include https://*.bilibili.com/*
// @include https://pan.baidu.com/disk/*
// @exclude https://message.bilibili.com/*
// @connect baidu.com
// @connect baidupcs.com
// @connect bilibili.com
// @connect 111.229.37.218
// @connect 127.0.0.1
// @connect localhost
// @connect self
// @grant GM_cookie
// @grant GM_download
// @grant GM_deleteValue
// @grant GM_getValue
// @grant GM_setValue
// @grant GM_setClipboard
// @grant GM_openInTab
// @grant GM_xmlhttpRequest
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
