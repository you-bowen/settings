// ==UserScript==
// @name colab重新连接
// @namespace http://tampermonkey.net/
// @version 1.2
// @description Automatically reconnect to Colab's session without clicking button.
// @author PartMent
// @match https://colab.research.google.com/*
// @match http://colab.research.google.com/*
// @match https://*.research.google.com/*
// @match http://*.research.google.com/*
// @license MIT
// @grant none
// ==/UserScript==

//Keep Page Active
Object.defineProperty(document, 'visibilityState', {value: 'visible', writable: true});
Object.defineProperty(document, 'hidden', {value: false, writable: true});
document.dispatchEvent(new Event("visibilitychange"));

//Define MutationObserver to automatically reconnect
var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
if (MutationObserver) console.log('Auto reconnector is enabled.');
var observer = new MutationObserver(function(mutations) {
    console.log('Detected DOM changes.');
    setTimeout(function () {
        var ok = document.getElementById('ok');
        if(ok.textContent.includes("連接") || ok.textContent.includes("连接") || ok.textContent.includes("Connect") || ok.textContent.includes("connect") || ok.textContent.includes("CONNECT")) {
            console.log('Reconnecting...');
            ok.click();
            console.log('Connected');
        }
    }, 3000);
});
observer.observe(document.body, {childList: true});