// ==UserScript==
// @name         过滤 - 百度知道
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://jingyan.baidu.com/article/*
// @grant        none
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

(function() {

    $('#exp-article > div.wgt-feeds-video > div.clearfix.feeds-video-box').remove()
    $('#format-exp > div.read-whole-mask > div.read-whole > span').click()
    $('#breadcrumb').remove()
    $('#wgt-like').remove()
    $('#main-content > div').remove()
    $('#format-exp > div.prompt').remove()
    $('#format-exp > div:nth-child(2) > h2').remove()
    $('#exp-article > div.wgt-feeds-video > div.f-light.feeds-video-one-view').remove()
    $('#exp-article > div.wgt-feeds-video > div.exp-title.clearfix').remove()
    $('body > div.wide-screen > nav').remove()
    $('#task-panel-wrap > div.task-panel-entrance').remove()
    $('#aside').remove()
    $('#bread-wrap').remove()
    $('#format-exp > div:nth-child(1) > div > div > div > p').remove()
    $('#top-search-box').remove()
    $('body > div.wide-screen > section > div.warning-warpper').remove()
    $('#exp-article > div.exp-title.clearfix').remove()
    $('#usrbar').remove()
    $('#exp-article > div.wgt-thumbs.clearfix').remove()
})();