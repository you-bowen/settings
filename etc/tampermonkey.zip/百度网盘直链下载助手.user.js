// ==UserScript==
// @name              百度网盘直链下载助手
// @name:en           Baidu Netdisk Assistant
// @name:zh           百度网盘直链下载助手
// @name:zh-CN        百度网盘直链下载助手
// @name:ja           Baidu Netdiskストレートチェーンダウンロードアシスタントv4
// @namespace         https://github.com/syhyz1990/baiduyun
// @version           4.0.0.1
// @description       This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:en    [Baidu Netdisk Assistant] is an oil monkey plug-in that does not require clients to obtain the real download address of Baidu Netdisk files. It supports Windows, Mac, Linux, Android and other platforms. Multithreaded acceleration tools such as IDM and XDown can be used. Accelerate download, support remote download, new upgrade of version 4.0.0.
// @description:ja    [Baidu Netdiskストレートチェーンダウンロードアシスタント]は、クライアントがBaidu Netdiskファイルの実際のダウンロードアドレスを取得する必要のないオイルモンキープラグインです。Windows、Mac、Linux、Android、およびその他のプラットフォームをサポートしています。IDMやXDownなどのマルチスレッドアクセラレーションツールを使用できます。 ダウンロードの高速化、リモートダウンロードのサポート、バージョン4.0.0の新しいアップグレード。
// @author            syhyz2020
// @license           AGPL
// @supportURL        https://github.com/syhyz1990/baiduyun
// @match             *://pan.baidu.com/disk/home*
// @match             *://yun.baidu.com/disk/home*
// @match             *://pan.baidu.com/s/*
// @match             *://yun.baidu.com/s/*
// @match             *://pan.baidu.com/share/*
// @match             *://yun.baidu.com/share/*
// @connect           baidu.com
// @connect           baidupcs.com
// @connect           *
// @run-at            document-idle
// @grant             unsafeWindow
// @grant             GM_xmlhttpRequest
// @grant             GM_setClipboard
// @grant             GM_setValue
// @grant             GM_getValue
// @grant             GM_deleteValue
// @grant             GM_openInTab
// @grant             GM_registerMenuCommand
// @grant             GM_unregisterMenuCommand
// ==/UserScript==
