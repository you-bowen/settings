// ==UserScript==
// @name         过滤 - 淘宝
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.taobao.com/
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

(function() {
    //淘宝
    $(".screen-outer.clearfix").remove()
    $(".tbh-nav.J_Module.tb-pass").remove()
    $(".tbh-banner.J_Module.tb-pass").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".layer").remove()
    $(".tb-footer.tb-footer-with-logo").remove()
    $("#J_SiteFooter").remove()
    $("body > div.tb-footer.tb-footer-with-logo").remove()
})();