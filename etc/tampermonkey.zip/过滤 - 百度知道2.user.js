// ==UserScript==
// @name         过滤 - 百度知道2
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://zhidao.baidu.com/question/*
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// @grant        none

// ==/UserScript==

(function() {
    'use strict';
    $('#userbar').remove()
    $('#j-nav-menu-container').remove()
    $('#qb-side').remove()
    $('#ask-info').remove()
    $('#qb-content > div.question-all-answers-number').remove()
    $('body > div.wgt-footer-new').remove()
    $('body > div.head-wrap').remove()
    // Your code here...
})();