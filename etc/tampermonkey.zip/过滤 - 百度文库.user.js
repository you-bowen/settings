// ==UserScript==
// @name         过滤 - 百度文库
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://wenku.baidu.com/*/*
// @grant        none
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

(function() {
    'use strict';
    $('#right-wrapper-id').remove()
    $('#app > div.header-wrapper.no-full-screen.new-header').remove()
    $('#app > div.content-wrapper > div.left-wrapper.zoom-scale > div:nth-child(1)').remove()
    $('#app > div.lazy-load > div.vip-member-pop-content > div > div.top-theme-tips-wrap > div').remove()
    $('#app > div.content-wrapper > div.left-wrapper.zoom-scale > div.no-full-screen > div.lazy-load').remove()
    $('#app > div.lazy-load').remove()
    $('#app > div.content-wrapper > div.left-wrapper.zoom-scale > div.reader-wrap > div.try-end-fold-page > div.fold-page-content > div.fold-page-text > span').click()
    // Your code here...
})();